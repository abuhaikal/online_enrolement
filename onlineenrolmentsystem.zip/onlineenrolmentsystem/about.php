   <!-- /.row -->
          
                     
            <div class="row">
                 
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3><b>  Mission and Vision</b>
                           </h3>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <p>
                               <h1> VISION</h1>

                                    To become a university of choice in nurturing professionals impacting the nation.

                                     

                                   <h1>  MISSION</h1>

                                    Develop ethical, holistic and balanced professional, To utilize knowledge and innovative contemporary technologies to contribute towards the development of the nation.

                                     

                                   <h1> GOALS</h1>
                                   <ul>
                                    <li>To provide opportunities to pursue professionally recognised programmes.</li>
                                    <li>To provide vibrant and invitational programmes relevant to current market needs and customers's demands.</li>
                                    <li>To design programmes that inculcate graduates' synergetic talents.</li>
                                    <li>To ensure that graduates are adequately prepared for the local and global workforce.</li>
                                    <li>To establish human resource development programmes as tool for assimilating the value of society.</li>
                                    <li>To establish a distinctive and accountable centre of excellence in managing research, consultation and services.</li>
                                   </ul>
                                </p>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-6 -->
            </div>
           